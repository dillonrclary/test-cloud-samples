using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace CreditCardValidator.iOS
{
	partial class ValidCreditCardController : UIViewController
	{
		public ValidCreditCardController (IntPtr handle) : base (handle)
		{
		}
	}
}
